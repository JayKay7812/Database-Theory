<!--
  撰写人：秦浩洋
  班级：18 本科 本地化
  学号：201811580018
-->
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf8">
    <title>Simple Upload-Bilingo Engine</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <style media="screen">
    body
    {
      padding-top:50px;
      margin:0 auto;
      text-align: center;
    }
    .starter
    {
      padding:25px 15px;
    }
    div
    {
      margin:5px 10px 10px;
    }
    .clickable
    {
      width:100px;
    }
    </style>
    <script type="text/javascript">
    function back_home()
    {
      window.location.href="../../index.php";
    }
    function back_mode_1()
    {
      window.location.href="mode_1.php";
    }
    </script>
  </head>
  <body>
    <?php
  	  if(!isset($_POST['submit']))
  	  {
  	    exit(' ');
  	  }
  	?>
    <div id="nav">
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <strong><a href="../../index.php" class="navbar-brand">Bilingo Engine</a></strong>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li> <a href="../../index.php" class="active">Home</a> </li>
              </ul>
            </div>
          </div>
      </nav>
    </div>
    <?php
      include ('../conn.php');

	$domain=$_POST["domain"];
    $file_id = mysqli_insert_id($conn);
    echo "<table class='table table-bordered' border='1' width='300px' align='center'>
            <tr>
            <th>CN</th>
            <th>EN</th>
			<th>Domain</th>
            </tr>";
		$zh = $_POST["zh_CN"];
	  $en = $_POST["en_US"];

    echo"<tr>";
  	echo "<td>".$zh."</td>";
  	echo "<td>".$en."</td>";
	echo "<td>".$domain."</td>";
  	echo "</tr>";
    $type=$_POST["typer"];

    if($type=="TM")
    {
      $insert_sql = "INSERT INTO `translation_memory` (`TM_ID`,`zh_CN`, `en_US`,`domain`) VALUES ('$file_id','$zh', '$en','$domain')";
    }
    else if($type=="Term")
    {
      $insert_sql = "INSERT INTO `terminology` (`Term_ID`,`zh_CN`, `en_US`,`domain`) VALUES ('$file_id','$zh', '$en','$domain')";
    }

    $status = mysqli_query($conn,$insert_sql);

		if(!$status)
		{
      echo "<script>alert('Data insert ERROR!');</script>";
		}
		else
		{
      echo "<script>alert('Data insert success!');</script>";
		}

    ?>
    <div>
      <div class="starter">
        <h1>All Done! What's next?</h1>
        <input type="button" class="btn btn-default" name="" value="Return to Home" style="color:white;background:rgb(231, 145, 160);" onclick="back_home()">
        <input type="button" class="btn btn-default" name="" value="Upload More" style="color:white;background:rgb(231, 145, 160);" onclick="back_mode_1()">
      </div>
  </div>
  </body>
</html>

<!--?php
      if(!isset($_POST['submit']))
      {
        //exit('闈炴硶璁块棶!');
        Header("Location: login.php");
      }
    ?-->
