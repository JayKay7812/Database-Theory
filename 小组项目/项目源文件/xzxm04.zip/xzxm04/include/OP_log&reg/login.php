<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<?php
if($_GET['action'] == "userlogin"){
        if(!$_SESSION['username']){

             Header("Location: include/OP_log&reg/user.php");
        }
        else
        {
          echo "<script>alert('You are already logged in!');location.href='javascript:history.back(-1);';</script>";
        }
}

else if($_GET['action'] == "adminlogin"){
        if(!$_SESSION['adminusername']){

             Header("Location: include/OP_log&reg/admin.php");
        }
        else
        {
          echo "<script>alert('You are already logged in!');location.href='javascript:history.back(-1);';</script>";
        }
}

/*else if($_GET['action'] == "upload"){
        if($_SESSION['adminusername']){


           Header("Location: mode_1.php");
        }
        else if($_SESSION['username']){

          Header("Location: mode_1.php");
        }
        else
        {
          Header("Location: login.php");

        }
}*/
?>
