<!--
  撰写人：秦浩洋
  班级：18 本科 本地化
  学号：201811580018
-->
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf8">
    <title>File Uplioad</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <style media="screen">
    body
    {
      margin:0 auto;
      text-align: center;

    }
    div
    {
      margin:5px 10px 10px;
    }
    .clickable
    {
      width:100px;
    }
    </style>
    <script type="text/javascript">
    function back_home()
    {
      window.location.href="../../index.php";
    }
    function back_mode_2()
    {
      window.location.href="mode_2.php";
    }
    </script>

  </head>
  <body>
    <div id="nav">
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <strong><a href="../../index.php" class="navbar-brand">Bilingo Engine</a></strong>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li> <a href="../../index.php" class="active">Home</a> </li>
              </ul>
            </div>
          </div>
      </nav>
    </div>
	<?php
	  if(!isset($_POST['submit']))
	  {
	    //exit('非法访问!');
	    Header("Location: login.php");
	  }
	?>
    <?php
    include("../conn.php");

    if($_FILES["file"]["error"]>0)
    {
      echo "Error:".$FILES["file"]["error"]."<br/>";
    }
    else
    {
      echo "Upload:".$_FILES["file"]["name"]."<br/>";
      echo "Type:".$_FILES["file"]["type"]."<br/>";
      echo "Size:".($_FILES["file"]["size"]/1024)."Kb<br/>";
      echo "Stored in:".$_FILES["file"]["tmp_name"];
    }
    if($_FILES["file"]["type"] == "application/xml")
    {
      echo "<br/>";
      echo "This is an XML file.";
    }
    if(file_exists("upload/".$_FILES["file"]["name"]))
    {
      echo $_FILES["file"]["name"]."already exists.";
    }
    else
    {
      $file = $_FILES["file"];
      $filename=$file["tmp_name"];
      $pinfo=pathinfo($file["name"]);
      $ftype=$pinfo["extension"];
      $qianzhui=date("ymdhis").rand();
      $savename=$qianzhui.".".$ftype;
      $destination="../../upload/".$savename;
      move_uploaded_file($_FILES["file"]["tmp_name"], $destination);
      echo "Stored in: ".$destination;
      $xml = simplexml_load_file($destination);
      $json=json_encode($xml);
      $jsondata=json_decode($json,true);
      $file_id = mysqli_insert_id($conn);
      $flag=1;
      $i=1;
	  $domain=$_POST["domain"];
      echo "<table class='table table-bordered' border='1' width='300px' align='center'>
              <tr>
              <th>EN</th>
              <th>CN</th>
			  <th>Domain</th>
              </tr>";
      foreach ($jsondata["body"]["tu"] as $tu)
    	{
    		$zh = $tu["tuv"][0]["seg"]."<br>";
    	    $en = $tu["tuv"][1]["seg"]."<br>";

        echo"<tr>";
      	echo "<td>".$zh."</td>";
      	echo "<td>".$en."</td>";
		echo "<td>".$domain."</td>";
      	echo "</tr>";
        $type=$_POST["typer"];

        if($type=="TM")
        {
          $insert_sql = "INSERT INTO `translation_memory` (`TM_ID`,`zh_CN`, `en_US`,`domain`) VALUES ('{$file_id}','{$zh}', '{$en}','{$domain}')";
        }
        else if($type=="Term")
        {
          $insert_sql = "INSERT INTO `terminology` (`Term_ID`,`zh_CN`, `en_US`,`domain`) VALUES ('{$file_id}','{$zh}', '{$en}','{$domain}')";
        }

        $status = mysqli_query($conn,$insert_sql);

    		if(!$status)
    		{
          $flag=0;
    		}
      }
      if($flag==0)
  		{
        echo "<script>alert('Data insert ERROR!');</script>";
  		}
  		else
  		{
        echo "<script>alert('Data insert success!');</script>";
  		}
      echo "</table>";
    }
    ?>
    <div>
      <div class="starter">
        <h1>All Done! What's next?</h1>
        <input type="button" class="btn btn-default" name="" value="Return to Home" onclick="back_home()" style="color:white;background:rgb(231, 145, 160);">
        <input type="button" class="btn btn-default" name="" value="Upload More" onclick="back_mode_2()" style="color:white;background:rgb(231, 145, 160);">
      </div>
  </div>
  </body>
</html>
