<!--
  撰写人：秦浩洋
  班级：18 本科 本地化
  学号：201811580018
-->
<?php
include ('../conn.php');
$where="";
$url="";
if(!empty($_GET['$searcher']))
{
$where="where zh_CN like '%".$_GET['searcher']."%' or en_US like '%".$_GET['searcher']."%'";
$url="&searcher=".$_GET['searcher']."&domain=".$_GET['domain']."&typer=".$_GET['typer'];
}
  $searchterm=$_GET['searcher'];
  $type=$_GET['typer'];
  $domain=$_GET['domain'];
  if($type=="TM")
  {
    $sql = "SELECT *
            FROM translation_memory
            WHERE domain='$domain' and zh_CN LIKE '%$searchterm%' or en_US LIKE '%$searchterm%'";
  }
  else if($type=="Term")
  {
    $sql = "SELECT *
            FROM terminology
            WHERE domain='$domain' and zh_CN LIKE '%$searchterm%' or en_US LIKE '%$searchterm%'";
  }
  $huoqu = mysqli_query($conn,$sql);
  if(mysqli_num_rows($huoqu)!=0){
            $allNum = mysqli_num_rows($huoqu);
  }

$pagesize=1;
$maxpage=ceil($allNum/$pagesize);
$page=isset($_GET['page'])?$_GET['page']:1;
if($page <1)
{
$page=1;
}
if($page>$maxpage)
{
$page=$maxpage;
}
$limit=" limit ".($page-1)*$pagesize.",$pagesize";
if($type=="TM")
{
$sql = "SELECT *
    FROM translation_memory
    WHERE domain='$domain' and zh_CN LIKE '%$searchterm%' or en_US LIKE '%$searchterm%' order by zh_CN desc {$limit}";
}
else if($type=="Term")
{
$sql = "SELECT *
    FROM terminology
    WHERE domain='$domain' and zh_CN LIKE '%$searchterm%' or en_US LIKE '%$searchterm%' order by zh_CN desc {$limit}";
}
$huo = mysqli_query($conn,$sql);
?>
