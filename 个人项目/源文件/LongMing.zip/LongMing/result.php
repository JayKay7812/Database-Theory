<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Long·Ming</title>
</head>
<style>
body{
  text-align: center;
}
div
{
  margin:0px auto;
  padding:10px;
  width:1000px;
  height:20px;
}
</style>
<body>
<input type="button" value="返回" onclick="window.location='index.php';" style="font-size:40px" />
<?php
   $dbhost = 'localhost:3306';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '1234';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }

   mysqli_select_db($conn,"tpcc1000");
   mysqli_query($conn,"set names utf8");
   @$searcher =$_POST['searcher'];
   $sql = "SELECT *
            FROM article
            WHERE MATCH (keywords) AGAINST('$searcher')";
   $huoqu = mysqli_query($conn,$sql);
   $num = mysqli_num_rows($huoqu);
   echo "<div>";
   echo'<table border=1>';
   echo '<tr><td><h3>共计'.$num.'条数据</h3></td><td><h3>搜索词为：'.$searcher.'</h3></td></tr>';
   echo '</table>';
   echo "</div>";
   echo "<div>";
  echo "<table border='1'>
              <tr>
              <th>url</th>
  		        <th>标题</th>
              </tr>";
  while ($row = mysqli_fetch_array($huoqu,MYSQLI_ASSOC)) {
          echo "<tr>";
          echo "<td>"."<a href='{$row['url']}'>".$row['url']."</a>"."</td>";
          echo "<td>".$row['title']."</td>";
          echo "</tr>";
  	}
  echo "</table>\n";
  echo "</div>";
  mysqli_close($conn);
?>
</body>
</html>
