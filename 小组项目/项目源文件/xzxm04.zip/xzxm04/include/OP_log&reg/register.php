<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk"/>
<title>Register</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
<style type="text/css">
  fieldset{width:520px; margin: 0 auto;}
  legend{font-weight:bold; font-size:14px;}
  label{float:left; width:70px; margin-left:10px;}
  .left{margin-left:80px;}
  .input{width:150px;}
  span{color: #666666;}
  .log
  {
    margin:25px;
    padding:15px 15px;
  }
</style>
<script language=JavaScript>
<!--

function InputCheck(LoginForm)
{
  if (LoginForm.username.value == "")
  {
    alert("Please enter your username!");
    LoginForm.username.focus();
    return (false);
  }
  if (LoginForm.password.value == "")
  {
    alert("Please enter your password!");
    LoginForm.password.focus();
    return (false);
  }
}

//-->
</script>
</head>
<body>
  <div id="nav">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <strong><a href="../../index.php" class="navbar-brand">Bilingo Engine</a></strong>
          </div>
          <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li> <a href="../../index.php" class="active">Home</a> </li>
              <li> <a href="register.php?action=logout">Logout</a> </li>
            </ul>
          </div>
        </div>
    </nav>
  </div>
  <div class="container">
    <div class="log">
      <fieldset>
      <legend class="log">Register</legend>
      <form name="LoginForm" method="post" action="register.php" onSubmit="return InputCheck(this)">
        <center>
        <div class="form-group">
          <label class="control-label col-sm-2">Username: </label>
          <div style="width:50%;">
            <input type="text" class="form-control" id="username" name='username'>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2">Password: </label>
          <div style="width:50%;">
            <input type="password" class="form-control" id="password" name="password">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-5" style="width:75%; margin:0 20px;">
            <input type="submit" name="submit" id="submit" class="btn btn-default" style="margin-right:100px;color:white;background:rgb(231, 145, 160);" value="Submit"/>
        </div>
      </center>
      </form>
      </fieldset>
    </div>
  </div></body>
</html>


<?php

//包含数据库连接文件
include('../conn.php');
include("logout.php");
if(!isset($_POST['submit'])){
    exit(' ');
}
$username = $_POST['username'];
$password = $_POST['password'];

//注册信息判断
if(!preg_match('/^[\w\x80-\xff]{3,15}$/', $username)){
    echo "<script>alert('ERROR: User name illegal.');location.href='javascript:history.back(-1);'</script>";
}
if(strlen($password) < 6){
  echo "<script>alert('ERROR: Password too short.(6 characters or more)');location.href='javascript:history.back(-1);'</script>";
}

//检测用户名是否已经存在
$sql ="select User_ID from users where User_Name='$username' limit 1";
$check_query = mysqli_query($conn,$sql, MYSQLI_STORE_RESULT );
if(mysqli_fetch_array($check_query, MYSQLI_ASSOC)){
    echo "<script>alert('ERROR：Username ",$username," already exists.');location.href='javascript:history.back(-1);';</script>";
    exit;
}
//写入数据
$password = MD5($password);
$regdate = time();
$sql = "INSERT INTO users(User_Name,User_Password)VALUES('$username','$password')";
if(mysqli_query($conn,$sql)){
    echo "<script>alert('Register clear! Returing to login...');location.href='user.php';</script>";
} else {
    echo "<script>alert('Failed to insert data'",mysqli_error(),");location.href='user.php';</script>";
    echo "<script>alert('Returning to retry...');location.href='javascript:history.back(-1);';</script>";
}
?>
