/*
 Navicat Premium Data Transfer

 Source Server         : test
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : localhost:3306
 Source Schema         : xzxm

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 24/06/2020 15:28:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `Admin_ID` bigint(0) NOT NULL AUTO_INCREMENT,
  `Admin_Name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Admin_Password` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Admin_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'abcdef', 'e10adc3949ba59abbe56e057f20f883e');

-- ----------------------------
-- Table structure for terminology
-- ----------------------------
DROP TABLE IF EXISTS `terminology`;
CREATE TABLE `terminology`  (
  `Term_ID` bigint(0) NOT NULL AUTO_INCREMENT,
  `zh_CN` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `en_US` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `domain` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Term_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of terminology
-- ----------------------------
INSERT INTO `terminology` VALUES (1, '好', 'good', 'literature');
INSERT INTO `terminology` VALUES (2, '憨憨', 'fool', 'literature');

-- ----------------------------
-- Table structure for translation_memory
-- ----------------------------
DROP TABLE IF EXISTS `translation_memory`;
CREATE TABLE `translation_memory`  (
  `TM_ID` bigint(0) NOT NULL AUTO_INCREMENT,
  `zh_CN` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `en_US` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `domain` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`TM_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of translation_memory
-- ----------------------------
INSERT INTO `translation_memory` VALUES (1, 'March marks a turning point in the Earth’s celestial dance. <br>', '3月标志着地球公转的转折点。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (2, 'This month, we approach the first equinox of the calendar year, and the seasons officially ‘change’ after the equinox passes. <br>', '本月，我们临近公历的第一个昼夜平分点——春分，春分过后，季节正式交替。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (3, 'There are also a variety of interesting opportunities to get out and see some of the different objects in our night sky. <br>', '还有很多有趣的机会可以出去看看夜空中的不同天体。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (4, 'From opportunities to see many of the planets in our solar system to Messier objects galore, read on for all the night sky events in March to plan for.\n<br>', '从看太阳系行星的机会到浩如烟海的梅西耶的天体，请继续阅读以便计划您的三月份夜空活动。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (5, 'Where necessary, we have noted where you may need binoculars or a telescope to help you get the best view of each celestial event. <br>', '在您可能需要双筒或单筒望远镜的地方，我们已作出标注，以便您能得到观赏各个天体事件的最佳视野。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (6, 'If you need a telescope to help enjoy this month’s night sky events, we have a guide to the best stargazing telescopes. <br>', '如果您需要望远镜来观赏本月的夜空活动，我们将为您提供最佳的天文望远镜指南。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (7, 'From the Meade Polaris 130 (under $200) to the Orion Atlas 8 EQ-G GoTo ($2000), you can find one for your astronomy interest and budget.\n<br>', '从价格的1200元以下12000元，您可以找到一款符合预算的望远镜来满足您的天文爱好。\n<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (8, 'Read on for the best March night sky events to plan your month of stargazing.<br>', '请继续阅读来了解最 佳夜空活动并作出您的观星计划。<br>', 'Physics');
INSERT INTO `translation_memory` VALUES (9, 'testtesttest', '测试测试测试', 'Literature');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `User_ID` bigint(0) NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `User_Password` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`User_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (2, 'test', '05a671c66aefea124cc08b76ea6d30bb');

SET FOREIGN_KEY_CHECKS = 1;
