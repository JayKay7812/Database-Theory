<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>Long·Ming</title>
		<style>
		body{
			text-align: center;
		}
		div
		{
			margin:0px auto;
			padding:100px;
			width:350px;
			height:100px;
		}
		</style>

	</head>
	<body>
		<div class="header">
			<h1 style="font-size:50px;width:350px;">Long·Ming Search</h1>
		</div>
		<div class="search">
			<form action="result.php" method="post">
			    <table border=1 title="SEARCH">
			        <tr>
								<td>
									<input name="searcher" type="text" style="width:300px" placeholder="请输入查询词（如：教育、时尚等）" />
								</td>
		            <td>
		               <button type="submit">搜索</button>
		            </td>
			        </tr>
			    </table>
			</form>
		</div>
	</body>
</html>
