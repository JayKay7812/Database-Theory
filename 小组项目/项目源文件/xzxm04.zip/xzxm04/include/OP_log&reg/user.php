<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />

<title>Login-Bilingo Engine</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
<style type="text/css">
    fieldset{width:520px; margin: 0 auto;}
    legend{font-weight:bold; font-size:14px;}
    label{float:left; width:70px; margin-left:10px;}
    .left{margin-left:80px;}
    .input{width:150px;}
    span{color: #666666;}
    .log
    {
      margin:25px;
      padding:15px 15px;
    }
</style>
<script language=JavaScript>
<!--

function InputCheck(LoginForm)
{
  if (LoginForm.username.value == "")
  {
    alert("Please enter your username!");
    LoginForm.username.focus();
    return (false);
  }
  if (LoginForm.password.value == "")
  {
    alert("Please enter your password!");
    LoginForm.password.focus();
    return (false);
  }
}

//-->
</script>
</head>
<body>
  <div id="nav">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <strong><a href="../../index.php" class="navbar-brand">Bilingo Engine</a></strong>
          </div>
          <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li> <a href="../../index.php" class="active">Home</a> </li>
              <li> <a href="register.php">Register</a> </li>
              <li> <a href="user.php?action=logout">Logout</a> </li>
            </ul>
          </div>
        </div>
    </nav>
  </div>
  <div class="container">
    <div class="log">
      <fieldset>
      <legend class="log">Login</legend>
      <form name="LoginForm" method="post" action="user.php" onSubmit="return InputCheck(this)">
        <center>
        <div class="form-group">
          <label class="control-label col-sm-2">Username: </label>
          <div style="width:50%;">
            <input type="text" class="form-control" id="username" name='username'>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2">Password: </label>
          <div style="width:50%;">
            <input type="password" class="form-control" id="password" name="password">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-5" style="width:75%; margin:0 20px;">
            <input type="submit" name="submit" class="btn btn-default" style="margin-right:20px;color:white;background:rgb(231, 145, 160);" value="Submit"/>
            <a href="register.php"><input type="button" class="btn btn-default" style="color:white;background:rgb(231, 145, 160);" value="Register"/></a>
          </div>
        </div>
      </center>
      </form>
      </fieldset>
    </div>
  </div>
</body>
</html>



<?php
//包含数据库连接文件
include('../conn.php');
//注销登录
error_reporting(0);
if($_GET['action'] == "logout"){
    unset($_SESSION['userid']);
    unset($_SESSION['username']);
    echo "<script>alert('Logout successfully!');location.href='javascript:history.back(-1);';</script>";
    exit;
}

//登录
if(!isset($_POST['submit'])){
    exit('');
}
$username = htmlspecialchars($_POST['username']);
$password = MD5($_POST['password']);


//检测用户名及密码是否正确
$sql ="select User_ID from users where User_Name='$username' and User_Password='$password' limit 1";
$check_query = mysqli_query($conn,$sql, MYSQLI_STORE_RESULT );
if($result = mysqli_fetch_array($check_query, MYSQLI_ASSOC)){
    //登录成功
    $_SESSION['username'] = $username;
    $_SESSION['userid'] = $result['uid'];
    echo "<script>alert('Login successfully!');location.href='../../index.php';</script>";
    exit;
} else {
    alert("-1");
    exit('Login failed! Click here to<a href="javascript:history.back(-1);">retry</a>');
}

?>
