<!--
  撰写人：潘光林（框架） 秦浩洋（逻辑）
  班级：18 本科 本地化
  学号：201811580116（潘）201811580018（秦）
-->
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Result-Bilingo Engine</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <style type="text/css">
        body
        {
          padding-top:50px;
          margin:0 auto;
          text-align: center;
        }
        div
        {
          padding:2px;
          margin:5px;
        }
        .starter
        {
          padding:25px 15px;
        }
        #searcher
        {
          width:350px;
    			height:25px;
        }
    </style>
  </head>
  <body>
    <div id="nav">
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <strong><a href="#" class="navbar-brand">Bilingo Engine</a></strong>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li> <a href="../../index.php" class="active">Home</a> </li>
                <li> <a href="result_2.php?action=logout">Logout</a> </li>
              </ul>
            </div>
          </div>
      </nav>
    </div>
    <div class="container">
      <div class="starter">
        <h1>Bilingo Engine</h1>
      </div>
      <form class="" action="result_1.php" method="get">
        <div class="form-group">
            <input type="text" placeholder="Input Here..." name="searcher" id="searcher" style="border-radius: 8px; width: 500px; height: 33px;" />
            <button class="btn btn-inverse" style="color:white;background:gray;">Search!</button>
          </div>
        <div class="non_texters">
          <div class="form_group">
            <label>Domain:</label>
            <select class="btn btn-default" name="domain" id="domain" style="color:white;background:gray;">
            <option value="Literature">Literature</option>
            <option value="Math">Math</option>
            <option value="Philosophy">Philosophy</option>
            <option value="Physics">Physics</option>
            <option value="Computer Science">Computer Science</option>
            </select>
          </div>
          <div class="form_control" name="type" id="type" style="margin:10px"><center>
              <label>Type:</label>
              <input type="radio" name="typer" id="Term" value="Term" required="required">
              <label for="Term">Term</label>
              <input type="radio" name="typer" id="TM" value="TM" required="required">
              <label for="TM">TM</label></center>
          </div>
      </form>
    </div>
    <?php
      include("search.php");
      include("../OP_log&reg/logout.php");
     ?>
    <table class="table table-bordered" border="1" width="500" align="center">
      <tr  style='margin:0 auto;'>
        <th>ID</th>
        <th>zh_CN</th>
        <th>en_US</th>
        <th>Domain</th>
        <th>Option</th>
      </tr>
    <?php
	   if (mysqli_num_rows($huo)==0)
     {
		     echo "<script>alert('No Result!');location.href='index.php';</script>";
	   }
	   else
     {
		     while($row= mysqli_fetch_array($huo,MYSQLI_ASSOC))
         {
      		if($type=="TM")
      		{
      		    $id=$row['TM_ID'];
      		}
      		else if($type=="Term")
      		{
		          $id=$row['Term_ID'];
		      }
    ?>
      <tr style='margin:0 auto;'>
        <td><?php echo $id ?></td>
        <td><?php echo $row['zh_CN'] ?></td>
        <td><?php echo $row['en_US'] ?></td>
        <td><?php echo $row['domain'] ?></td>
        <td width="144px">
        <div id="nav3">
        <?php echo "<a class='btn btn-default'style='color:white;background:rgb(231, 145, 160);font-size:15px;' href='../admin/del.php?code=".$id."&type=".$type."'><center>Delete</center></a></div>";?>
        <div id="nav3">
        <?php echo "<a class='btn btn-default'style='color:white;background:rgb(231, 145, 160);font-size:15px;' href='../admin/edit.php?code=".$id."&type=".$type."'><center>Modify</center></a></div>";?>
        </td>
      </tr>
    <?php }?>
	<?php }?>
      <tr>
        <td colspan="6">
          <?php
          echo " Currently at {$page} of {$maxpage} total page, {$allNum} term/TM(s) found";
          echo " <a href='result_2.php?page=1"."&searcher=".$_GET['searcher']."&domain=".$_GET['domain']."&typer=".$_GET['typer']."'>[First]</a> ";
          echo "<a href='result_2.php?page=".($page-1)."&searcher=".$_GET['searcher']."&domain=".$_GET['domain']."&typer=".$_GET['typer']."'>[Prev] </a>";
          echo "<a href='result_2.php?page=".($page+1)."&searcher=".$_GET['searcher']."&domain=".$_GET['domain']."&typer=".$_GET['typer']."'>[Next]</a>";
          echo " <a href='result_2.php?page={$maxpage}"."&searcher=".$_GET['searcher']."&domain=".$_GET['domain']."&typer=".$_GET['typer']."'>[Bottom]</a> ";
          ?>
        </td>
      </tr>
    </table>
  </body>
</html>
