<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<?php
//注销登录
error_reporting(0);
if($_GET['action'] == "logout"){
    $_SESSION = array();
      //判断 cookie 中是否保存 Session ID
       if(isset($_COOKIE[session_name()])){
         setcookie(session_name(),'',time()-3600, '/');
      }
      //彻底销毁 Session
      session_destroy();

    echo "<script>alert('Logout successfully!');location.href='javascript:history.back(-1);';</script>";
    exit;
}
?>
