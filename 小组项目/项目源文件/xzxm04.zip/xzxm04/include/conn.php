<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<?php
$dbhost = 'localhost:3306';  //mysql服务器主机地址
$dbuser = 'root';      //mysql用户名
$dbpass = '1234';//mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}

mysqli_select_db( $conn,'xzxm' );
mysqli_query($conn,"set names utf8");
?>
