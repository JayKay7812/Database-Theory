<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
 <?PHP
		$code = $_GET["code"];
		$type = $_GET["type"];
		$zh_CN = $_POST['zh_CN'];
		$en_US = $_POST['en_US'];
		$domain = $_POST['domain'];


		include "conn.php";
		if($type=='TM')
		{
			$sql = "update translation_memory set zh_CN='$zh_CN',en_US='$en_US',Domain_ID='$domain' where TM_ID='$code'";
		}
		else if ($type=='Term')
		{
			$sql = "update terminology set zh_CN='$zh_CN',en_US='$en_US',Domain_ID='$domain' where Term_ID='$code'";
		}
		$huoqu = mysqli_query($conn,$sql);
		echo mysqli_error($conn);
		if($huoqu)
		{
		    echo "<script>alert('修改成功!');location.href='index0.php';</script>";
		}
		else
		{
		    echo "修改失败！";
		}
	?>
