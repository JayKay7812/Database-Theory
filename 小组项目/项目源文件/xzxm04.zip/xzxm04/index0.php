<!--
  撰写人：潘光林（框架） 秦浩洋（逻辑）
  班级：18 本科 本地化
  学号：201811580116（潘）201811580018（秦）
-->
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <head>
     <script>
		 function goUpload()
		         {
		           var myName="<%=session.getAttribute('adminusername')%>";
		           if(myName=="")
		           {
		             alert("Please Login before Upload!");
		             window.location.href="login.php";
		           }
		           else
		           {
		             window.location.href="include/OP_upload/mode_1.php.php";
		           }
		         }
	 </script>
    </head>
    <style>
      body
      {
        padding-top:50px;
        margin:0 auto;
        text-align: center;
      }
      .starter
      {
        padding:25px 15px;
      }
      div
      {
        padding:2px;
        margin:5px
      }
      #searcher
      {
        width:350px;
  			height:25px;
      }
		</style>
  </head>
  <body>
    <div id="nav">
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <strong><a href="#" class="navbar-brand">Bilingo Engine</a></strong>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li> <a href="#" class="active">Home</a> </li>
                <li> <a href="include/OP_upload/mode_1.php">Upload</a> </li>
                <li> <a href="index0.php?action=adminlogin">Admin-Login</a> </li>
                <li> <a href="index0.php?action=logout">Logout</a> </li>
              </ul>
            </div>
          </div>
      </nav>
    </div>
    <div class="container">
      <div class="starter">
        <h1>Bilingo Engine</h1>
        <p>Welcome.</p>
      </div>
    </div>
    <form action="include/OP_search/result_2.php" method="get">
      <div class="form-group">
          <input type="text" placeholder="Input Here..." name="searcher" id="searcher" style="border-radius: 8px; width: 500px; height: 33px;" value="" />
          <button class="btn btn-inverse" style="color:white;background:rgb(231, 145, 160);">Search!</button>
        </div>
      <div class="non_texters">
        <div class="form_group">
          <label>Domain:</label>
          <select class="btn btn-default" name="domain" id="domain" style="color:white;background:rgb(231, 145, 160);">
          <option value="Literature">Literature</option>
          <option value="Math">Math</option>
          <option value="Philosophy">Philosophy</option>
          <option value="Physics">Physics</option>
          <option value="Computer Science">Computer Science</option>
          </select>
        </div>
        <div class="form_control" name="type" id="type" style="margin:10px"><center>
            <label>Type:</label>
            <input type="radio" name="typer" id="Term" value="Term" required="required">
            <label for="Term">Term</label>
            <input type="radio" name="typer" id="TM" value="TM" required="required">
            <label for="TM">TM</label></center>
        </div>
    </form>
		<?php
      include 'include/OP_log&reg/logout.php';
      include 'include/OP_log&reg/login.php';
		?>
  </body>
</html>
