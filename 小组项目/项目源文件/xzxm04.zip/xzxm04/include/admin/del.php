<!--
  撰写人：段孝辰
  班级：18 本科 本地化
  学号：201811580724
-->
<?PHP
		$code = $_GET['code'];
		$type = $_GET['type'];

		include "../conn.php";
		if($type=='TM')
		{
			$sql = "delete from translation_memory where TM_ID ='$code'";
		}
		else if ($type=='Term')
		{
			$sql = "delete from terminology where Term_ID ='$code'";
		}
		$huoqu = mysqli_query($conn,$sql);
		if($huoqu)
		{
		    echo "<script>alert('Delete successfully!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
		}
		else
		{
		    echo "Failed to delete entry!";
		}

	?>
