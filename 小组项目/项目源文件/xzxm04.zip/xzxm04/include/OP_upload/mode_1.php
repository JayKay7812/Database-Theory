<!--
  撰写人：秦浩洋
  班级：18 本科 本地化
  学号：201811580018
-->
<!DOCTYPE html>
<html>
  <head>
    <meta content="text/html;charset=utf-8">
    <title>Simple Upload-Bilingo Engine</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <style type="text/css">
      body
      {
        padding-top:50px;
        margin:0 auto;
        text-align: center;
      }
      .starter
      {
        padding:25px 15px;
      }
      div
      {
        padding:2px;
      }
      #zh_area
      {
        margin:20px;
        position:relative;
        float:left;
      }
      #en_area
      {
        margin:20px;
        position:relative;
        float:left;
      }
      .form_group
      {
        position:relative;
      }
      .texters
      {
        margin:0 auto;
        width:700px;
        height:300px;
      }
    </style>
    <script type="text/javascript">
      function back_mode_2()
      {
        window.location.href="mode_2.php";
      }
    </script>
  </head>
  <body>
    <div id="nav">
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <strong><a href="#" class="navbar-brand">Bilingo Engine</a></strong>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
              <ul class="nav navbar-nav">
                <li> <a href="../../index.php" class="active">Home</a> </li>
                <li> <a href="mode_1.php?action=logout">Logout</a> </li>
              </ul>
            </div>
          </div>
      </nav>
    </div>
	  <?php
	  if(!$_SESSION['username']&&!$_SESSION['adminusername']){
	      //exit('非法访问!');
        echo "<script>alert('Please Login before upload!');location.href='../OP_log&reg/user.php';</script>";
	  }
	  ?>
    <div class="container">
      <div class="starter">
        <h1>Bilingo Engine</h1>
      </div>
      <form action="upload_entry.php" method="post" enctype="multipart/form-data">
        <div class="texters">
          <div class="form_group" id="zh_area">
            <div>
              <label for="zh_CN">zh_CN</label>
            </div>
            <textarea rows="10" cols="90" class="form-control" name="zh_CN" id="zh_CN" style="width:300px;height:200px;" required></textarea>
          </div>
          <div class="form_group" id="en_area">
            <div>
              <label for="en_US">en_US</label>
            </div>
            <textarea rows="10" cols="90" class="form-control" name="en_US" id="en_US" style="width:300px;height:200px;" required></textarea>
          </div>
        </div>
        <div class="non_texters">
          <div class="form_group">
            <label>Domain:</label>
            <select class="btn btn-default" name="domain" id="domain" style="color:white;background:rgb(231, 145, 160);">
              <option value="Literature">Literature</option>
              <option value="Math">Math</option>
              <option value="Philosophy">Philosophy</option>
              <option value="Physics">Physics</option>
              <option value="Computer Science">Computer Science</option>
            </select>
          </div>
          <div class="form_control" name="type" id="type">
              Type:
              <input type="radio" name="typer" id="Term" value="Term" required="required">
              <label for="Term">Term</label>
              <input type="radio" name="typer" id="TM" value="TM" required="required">
              <label for="TM">TM</label>
          </div>
          <input type="submit" class="btn btn-default" name="submit" value="Submit Now" style="width:100px;color:white;background:rgb(231, 145, 160);"/>
        </div>
      </form>
      <div>
        <input type="button" class="btn btn-default" name="back_mode_1" value="File Upload" onclick="back_mode_2()" style="width:100px;color:white;background:rgb(231, 145, 160);"/>
      </div>
    </div>
    <?php
    include '../OP_log&reg/logout.php';
    ?>
  </body>
</html>
